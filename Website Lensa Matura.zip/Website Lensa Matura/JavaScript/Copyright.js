const year = new Date().getFullYear();
document.getElementById("copyright").textContent =
  `© ${year} SMAN 1 Kraksaan — All Rights Reserved`;
